import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Libri } from '../models/libri'

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
 urlBase = 'http://localhost:4201';
 mioLibro: Libri[] = [];

 //permette ai valori di essere chimati su più observer. Ad ogni incremento la vista si aggiornerà

  constructor(private http: HttpClient) {
   }

  caricaLibro() {
    return this.http.get<Libri[]>(`${this.urlBase}/products`)
  }

  dettagliLibro(id: number){
    return this.http.get<Libri>(`${this.urlBase}/products/${id}`)
  }

  ottieni(){
    return this.mioLibro
  }

  add(product: any){
   return this.mioLibro.push(product);
    }

}
