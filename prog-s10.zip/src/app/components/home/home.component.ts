import { Component, OnInit } from '@angular/core';
import { Libri } from '../../models/libri';
import { ProductsService } from 'src/app/service/products.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  libriInArrivo: Libri[] | undefined;


  constructor(private prodSrv: ProductsService) { }

  ngOnInit(): void {
    this.prodSrv.caricaLibro().subscribe((libriArrivati) => {
      this.libriInArrivo = libriArrivati; //foto in arrivo sarà riempito da fotoArrivate
    })
  }

}
