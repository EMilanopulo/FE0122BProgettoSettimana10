import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Route } from '@angular/router';

import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { CarrelloComponent } from './components/carrello/carrello.component';
import { DettagliComponent } from './components/dettagli/dettagli.component';

const routes : Route[] = [
  {
    path: "", //questo è l'indirizzo di home
    component: HomeComponent,
  },
  {
    path: "carrello",
    component: CarrelloComponent
  },
  {
  path: "dettagli/:id",
  component: DettagliComponent,
}
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    DettagliComponent,
    CarrelloComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
