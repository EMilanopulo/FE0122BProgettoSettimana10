import { Injectable } from '@angular/core';
import { Libri } from '../models/libri';
import { Subject } from 'rxjs';
import { ProductsService } from '../service/products.service'


@Injectable({
  providedIn: 'root'
})
export class CarrelloService {
  mioLibro: Libri[] = [];

  sub = new Subject<number>();

  contatore = 0;

  constructor(private prodSrv: ProductsService) {
    this.mioLibro = [];
   }

  visualizzaCarrello(){
    return this.mioLibro
  }

  conta() {
    this.contatore++;
    this.sub.next(this.contatore);
  }

  recupera() {
    return this.mioLibro;
  }

  get(): Promise<Libri[]>{
    return new Promise(() =>{
        this.prodSrv.caricaLibro()
        console.log()
    })
  }

  aggiorna(data: Partial<Libri>, id: number) {

    //gli dici di prendere id di post e se è uguale all'id che gli arriva cambia contenuto di post con quello di data, sennò post
    this.mioLibro = this.mioLibro.map(libro => libro.id == id?{...libro,...data}: libro);

    //find restituisce il valore del primo elemento dell'array che rispetta quel valore, sennò restituisce undefined
    return this.mioLibro.find(libro => libro.id == id) as Libri; //è necessario indicare as Post perchè abbiamo dei partial

    }


}


