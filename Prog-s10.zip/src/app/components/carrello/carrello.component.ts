import { Component, OnInit, Input } from '@angular/core';
import { CarrelloService } from '../../service/carrello.service'
import { Libri } from 'src/app/models/libri';
import { ProductsService } from 'src/app/service/products.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-carrello',
  templateUrl: './carrello.component.html',
  styleUrls: ['./carrello.component.scss']
})
export class CarrelloComponent implements OnInit {
  mioLibro: Libri[] | undefined;
 risultato = this.prodSrv.ottieni();


  constructor(private carSrv: CarrelloService, private prodSrv: ProductsService, private router: ActivatedRoute) {}


  ngOnInit(): void {
    this.prodSrv.caricaLibro().subscribe((prodarrivato) => {
      this.mioLibro = prodarrivato;
    });
  }

}
