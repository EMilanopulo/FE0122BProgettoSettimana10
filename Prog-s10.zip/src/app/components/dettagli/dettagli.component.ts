import { Component, OnInit  } from '@angular/core';
import { Libri } from '../../models/libri';
import { ProductsService } from 'src/app/service/products.service';
import { ActivatedRoute } from '@angular/router';
import { CarrelloService } from '../../service/carrello.service';

@Component({
  selector: 'app-dettagli',
  templateUrl: './dettagli.component.html',
  styleUrls: ['./dettagli.component.scss']
})
export class DettagliComponent implements OnInit {
  mioLibro!: Libri;
  libri!: Libri[];



  constructor(private prodSrv: ProductsService, private router: ActivatedRoute, private carrelloSrv: CarrelloService) { }

  ngOnInit(): void {
    this.router.params.subscribe(async(params)=>{
      const id = +params['id'];
      this.prodSrv.dettagliLibro(id).subscribe((libro) => {
        this.mioLibro = libro
      })
    })
}

aggiungiCarrello(){
  this.carrelloSrv.conta();
  console.log(this.mioLibro);
  return this.prodSrv.add(this.mioLibro) //PUSH
}
}
