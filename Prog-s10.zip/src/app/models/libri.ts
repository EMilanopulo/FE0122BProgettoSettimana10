export interface Libri {
  id: number,
    titolo: string,
    autore: string,
    annoPubblicazione: number,
    editore: string,
    prezzo: number,
    completed: boolean
}
